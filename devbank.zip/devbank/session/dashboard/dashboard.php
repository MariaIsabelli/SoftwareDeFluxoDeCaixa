<?php
// Incluindo os arquivos de configuração e de conexão com o banco de dados
include("../../configuration/connection.php"); // Conexão com o banco
include("mes.php"); // Arquivo de configuração para a manipulação dos meses

// Iniciando a sessão para controle de autenticação
session_start();
if(!isset($_SESSION['email']) == true  and(!isset($_senha) == true )){ // Verificando se a sessão de login existe
  header('Location: ../../login/form-login.php'); // Redireciona para o login caso não esteja autenticado
}
?>

<?php
// Inicializando as variáveis de receita e despesa
$Receita = 0;
$Despesa = 0;

// Consulta para calcular o total de entradas (receitas) por mês
$SQLReceita = "SELECT DATE_FORMAT(Data_Entrada, '%m') AS mes, SUM(ValorEntrada) AS totalentrada FROM entradavalores WHERE ativo = 1 AND DATE_FORMAT(Data_Entrada, '%Y') = 2023 GROUP BY DATE_FORMAT(Data_Entrada, '%m');";
$ConsultaReceita = mysqli_query($conexao, $SQLReceita);

// Arrays para armazenar os valores mensais de receitas e despesas
$MesesEntrada = array(1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0, 6 => 0, 7 => 0, 8 => 0, 9 => 0, 10 => 0, 11 => 0, 12 => 0);
$MesesSaida = array(1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0, 6 => 0, 7 => 0, 8 => 0, 9 => 0, 10 => 0, 11 => 0, 12 => 0);

// Calculando a soma das receitas por mês
while($ValorReceita = mysqli_fetch_assoc($ConsultaReceita)){
  $Receita += $ValorReceita['totalentrada']; // Somando as receitas
  $MesesEntrada[$ValorReceita['mes']] += $ValorReceita['totalentrada']; // Armazenando os valores por mês
}

// Consulta para calcular o total de saídas (despesas) por mês
$SQLDespesa  = "SELECT DATE_FORMAT(Data_Saida, '%m') AS mes, SUM(ValorSaida) AS totalsaida FROM saidavalores WHERE ativo = 1 AND DATE_FORMAT(Data_Saida, '%Y') = 2023 GROUP BY DATE_FORMAT(Data_Saida, '%m');";
$ConsultaDespesa = mysqli_query($conexao ,$SQLDespesa);

// Calculando a soma das despesas por mês
while($ValorDespesa = mysqli_fetch_assoc($ConsultaDespesa)){
  $Despesa += $ValorDespesa["totalsaida"]; // Somando as despesas
  $MesesSaida[$ValorDespesa['mes']] += $ValorDespesa['totalsaida']; // Armazenando os valores por mês
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../../css/dashboard2.css">
  <title>Dashboard</title>
</head>

<body>

  <header>
    <span id="btnMenu" id="btnClose" class="material-symbols-outlined hamburguer">
      menu
    </span>
    <a href="./logout.php"><span class="material-symbols-outlined"> logout </span></a>
  </header>

  <!-- Navegação menu -->
  <nav id="menu" class="menu effect">
    <ul>
      <li><a class="menu_link" href="#"><i class="bi bi-house-door-fill"></i> Dashboard</a></li>
      <li><a class="menu_link" href="../receita/receitas-user.php"><i class="bi bi-cash-stack"></i> Receita</a></li>
      <li><a class="menu_link" href="../despesa/despesas-user.php"><i class="bi bi-cash-stack"></i> Despesas</a></li>
      <li><a class="menu_link" href="../user/list-view-user.php"><i class="bi bi-person-circle"></i> Usuários</a></li>
      <li><a class="menu_link" href="../user/form-create-user.php"><i class="bi bi-person-add"></i> Cadastro</a></li>
      <li><a class="menu_link" href="../suporte/suporte-user.php"><i class="bi bi-sliders"></i> Suporte</a></li>
    </ul>
  </nav>

  <!-- Exibição de receita, despesa e total -->
  <section class="stnDinheiro">
    <section>
      <article class="artDinheiroNome">
        <h3>Receita</h3>
      </article>
      <article class="artDinheiro">
        <p class="rs">R$</p>
        <h3><?php print(number_format($Receita, 2, ',', '.')); ?></h3>
      </article>
    </section>

    <section>
      <article class="artDinheiroNome">
        <h3>Despesa</h3>
      </article>
      <article class="artDinheiro">
        <p class="rs">R$</p>
        <h3><?php print(number_format($Despesa, 2, ',', '.')); ?></h3>
      </article>
    </section>

    <section>
      <article class="artDinheiroNome">
        <h3>Total</h3>
      </article>
      <article class="artDinheiro">
        <p class="rs">R$</p>
        <h3><?php print(number_format($Receita - $Despesa, 2, ',', '.')); ?></h3>
      </article>
    </section>
  </section>

  <!-- Tabela de Receitas e Despesas por Mês -->
  <div class="tabela">
    <table class="table table-responsive light">
      <thead>
        <tr>
          <th scope="col">Mês</th>
          <th scope="col">Receita</th>
          <th scope="col">Despesa</th>
          <th scope="col">Total</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $meses = [
          1 => "Janeiro", 2 => "Fevereiro", 3 => "Março", 4 => "Abril", 5 => "Maio", 6 => "Junho",
          7 => "Julho", 8 => "Agosto", 9 => "Setembro", 10 => "Outubro", 11 => "Novembro", 12 => "Dezembro"
        ];

        foreach($meses as $numero => $nome) {
          $entrada = number_format($MesesEntrada[$numero], 2, ',', '.');
          $saida = number_format($MesesSaida[$numero], 2, ',', '.');
          $total = number_format($MesesEntrada[$numero] - $MesesSaida[$numero], 2, ',', '.');
          echo "<tr>
                  <th scope='row'>$nome</th>
                  <td class='text-primary fw-bold'>R$ $entrada</td>
                  <td class='text-danger fw-bold'>R$ $saida</td>
                  <td class='fw-bold'>R$ $total</td>
                </tr>";
        }
        ?>
      </tbody>
    </table>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
